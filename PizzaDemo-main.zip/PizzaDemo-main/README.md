The system showcases the menu component of the system. The system contains buttons which do not work because they are meant to lead to other components of the system which
are not included in this prototype. The prototype includes a login screen, a menu screen, and a cart screen. User accounts and cart information are stored in a text file which simulates
the database of the system.
Login can be achieved through one of the two accounts which are setup for the prototype:
Username: "mom", Password: "pizzapassword123"
Username: "pop", Password: "olivepepperoni6"
Note: Cart only saves upon user logout
