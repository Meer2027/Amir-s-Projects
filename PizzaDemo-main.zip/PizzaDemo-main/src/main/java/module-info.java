module app.pizza_demofx.pizzademo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens app.pizza_demofx.pizzademo to javafx.fxml;
    exports app.pizza_demofx.pizzademo;
}