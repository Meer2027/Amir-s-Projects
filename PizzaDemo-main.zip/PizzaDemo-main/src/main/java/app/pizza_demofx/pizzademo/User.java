package app.pizza_demofx.pizzademo;
import java.util.ArrayList;

public class User {
    private String username;
    private String password;
    private ArrayList<PizzaMenuItem> cart;

    // constructor for user with empty cart
    public User(String username, String password){
        this.username = username;
        this.password = password;
        cart = new ArrayList<PizzaMenuItem>();
    }

    // constructor for user with cart
    public User(String username, String password, String str_cart){
        this.username = username;
        this.password = password;
        cart = new ArrayList<PizzaMenuItem>();
        // converting cart string into cart item
        String[] cart_items = str_cart.split("&&:");
        for(String s : cart_items){
            String[] item_parts = s.split("__:");
            if (item_parts[0].equals("drinkitem")){ // if the item is a drink
                cart.add(new Drink(item_parts[1],item_parts[2]));
            }
            else if (item_parts[0].equals("pizzaitem")){ // if the item is a pizza
                Pizza newPizza = new Pizza(item_parts[1],item_parts[2]);
                String[] toppings = item_parts[3].split("@@:");
                for(String t : toppings){
                    newPizza.addTopping(t);
                }
                cart.add(newPizza);
            }
        }
    }

    // checks if the password input matches the actual password
    public boolean passwordMatch(String pass){
        return pass.equals(password);
    }

    // checks if the username input matches the actual username
    public boolean userMatch(String user){
        return user.equals(username);
    }

    // returns the cart
    protected ArrayList<PizzaMenuItem> getCart(){
        return cart;
    }

    protected String getUsername(){
        return username;
    }

    //put cart item into string form for txt file
    public String saveString(){
        boolean firstTime = true;
        String saveStringUser = username + "," + password;
        if (!cart.isEmpty()){
            saveStringUser+=",";
            for (PizzaMenuItem p : cart) {
                if (!firstTime) {
                    saveStringUser += "&&:";
                    saveStringUser += p.saveString();
                } else {
                    saveStringUser += p.saveString();
                    firstTime = false;
                }
            }
        }
        return saveStringUser;
    }

}
