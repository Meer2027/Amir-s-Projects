package app.pizza_demofx.pizzademo;
import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class MenuController {
    private Pizza current_pizza; // pizza on "custom pizza" graphic box which can be added to cart
    private Drink current_drink; // drink on "custom drink" graphic box which can be added to cart

    // class constructor which initializes the current drink and pizza
    public MenuController(){
        current_drink = new Drink();
        current_pizza = new Pizza();
    }

    @FXML
    private Label pizza_description;

    @FXML
    private Label pizza_price;

    @FXML
    private Label drink_description;

    @FXML
    private Label drink_price;

    @FXML
    private Button cart_button;

    // when the screen is initialized, update the cart button in case there are already items in the cart
    public void initialize(){
        cart_button.setText("Continue to Cart (" + LoginController.getCurrentCart().size() + " items)");
    }

    @FXML // add pizza to the cart when "add to cart" button is pressed for the custom pizza
    protected void onPizzaAddedToCart() {
        LoginController.getCurrentCart().add(new Pizza(new ArrayList<String>(current_pizza.getToppings()), current_pizza.getCrustType(),current_pizza.getSize())); // create copy of current pizza and add to cart
        updateCartButtonText();
    }

    @FXML // add drink to the cart when "add to cart" button is pressed for the custom drink
    protected void onDrinkAddedToCart() {
        LoginController.getCurrentCart().add(new Drink(current_drink.getSize(),current_drink.getDrink())); // create copy of current drink and add to cart
        updateCartButtonText();
    }

    @FXML // when "continue to cart" button is pressed, change to the cart screen
    protected void onContinueToCart() {
        PizzaApplication.changeScene("cart.fxml");
    }

    @FXML // when sign out button is pressed, save user information and go back to login screen
    protected void onSignOut(){
        LoginController.saveUser();
        PizzaApplication.changeScene("login.fxml");
    }

    @FXML // add/remove Pepperoni from the pizza (note:case-sensitive)
    protected void togglePepperoni() {
        if(current_pizza.getToppings().contains("Pepperoni"))
            current_pizza.removeTopping("Pepperoni");
        else
            current_pizza.addTopping("Pepperoni");
        updatePizzaDisplays();
    }

    @FXML // add/remove Bacon from the pizza (note:case-sensitive)
    protected void toggleBacon() {
        if(current_pizza.getToppings().contains("Bacon"))
            current_pizza.removeTopping("Bacon");
        else
            current_pizza.addTopping("Bacon");
        updatePizzaDisplays();
    }

    @FXML // add/remove Sausage from the pizza (note:case-sensitive)
    protected void toggleSausage() {
        if(current_pizza.getToppings().contains("Sausage"))
            current_pizza.removeTopping("Sausage");
        else
            current_pizza.addTopping("Sausage");
        updatePizzaDisplays();
    }

    @FXML // add/remove Extra cheese from the pizza (note:case-sensitive)
    protected void toggleExtraCheese() {
        if(current_pizza.getToppings().contains("Extra cheese"))
            current_pizza.removeTopping("Extra cheese");
        else
            current_pizza.addTopping("Extra cheese");
        updatePizzaDisplays();
    }

    @FXML // add/remove Onion from the pizza (note:case-sensitive)
    protected void toggleOnion() {
        if(current_pizza.getToppings().contains("Onion"))
            current_pizza.removeTopping("Onion");
        else
            current_pizza.addTopping("Onion");
        updatePizzaDisplays();
    }

    @FXML // add/remove Bell pepper from the pizza (note:case-sensitive)
    protected void toggleBellPepper() {
        if(current_pizza.getToppings().contains("Bell pepper"))
            current_pizza.removeTopping("Bell pepper");
        else
            current_pizza.addTopping("Bell pepper");
        updatePizzaDisplays();
    }

    @FXML // add/remove Mushroom from the pizza (note:case-sensitive)
    protected void toggleMushroom() {
        if(current_pizza.getToppings().contains("Mushroom"))
            current_pizza.removeTopping("Mushroom");
        else
            current_pizza.addTopping("Mushroom");
        updatePizzaDisplays();
    }

    @FXML // add/remove Olive from the pizza (note:case-sensitive)
    protected void toggleOlive() {
        if(current_pizza.getToppings().contains("Olive"))
            current_pizza.removeTopping("Olive");
        else
            current_pizza.addTopping("Olive");
        updatePizzaDisplays();
    }

    @FXML
    protected void crustRegular(){
        current_pizza.setCrust("");
        updatePizzaDisplays();
    }

    @FXML
    protected void crustThin(){
        current_pizza.setCrust("Thin");
        updatePizzaDisplays();
    }

    @FXML
    protected void crustStuffed(){
        current_pizza.setCrust("Stuffed");
        updatePizzaDisplays();
    }

    @FXML
    protected void pizzaSizeSmall(){
        current_pizza.setSize("Small");
        updatePizzaDisplays();
    }

    @FXML
    protected void pizzaSizeMedium(){
        current_pizza.setSize("Medium");
        updatePizzaDisplays();
    }

    @FXML
    protected void pizzaSizeLarge(){
        current_pizza.setSize("Large");
        updatePizzaDisplays();
    }

    @FXML
    protected void pizzaSizeExtraLarge(){
        current_pizza.setSize("Extra Large");
        updatePizzaDisplays();
    }

    @FXML
    protected void updatePizzaDisplays() {
        pizza_description.setText(current_pizza.toStringShort());
        pizza_price.setText("$" + current_pizza.getPrice());
    }

    @FXML
    protected void drinkSizeSmall(){
        current_drink.setSize("Small");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkSizeMedium(){
        current_drink.setSize("Medium");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkSizeLarge(){
        current_drink.setSize("Large");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkTypeCocaCola(){
        current_drink.setDrink("Coca Cola");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkTypePepsi(){
        current_drink.setDrink("Pepsi");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkTypeLemonade(){
        current_drink.setDrink("Lemonade");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkTypeWaterBottle(){
        current_drink.setDrink("Bottled Water");
        updateDrinkDisplays();
    }

    @FXML
    protected void drinkTypeSweetTea(){
        current_drink.setDrink("Sweet Tea");
        updateDrinkDisplays();
    }

    @FXML
    protected void updateDrinkDisplays() {
        drink_description.setText(current_drink.toString());
        drink_price.setText("$"+current_drink.getPrice());
    }

    // update the text of the "continue to cart" button based on how many items are currently in the cart
    protected void updateCartButtonText(){
        if (LoginController.getCurrentCart().size() > 1)
            cart_button.setText("Continue to Cart (" + LoginController.getCurrentCart().size() + " items)");
        else if (LoginController.getCurrentCart().size() == 1) {
            cart_button.setText("Continue to Cart (1 item)");
        }
        else {
            cart_button.setText("Continue to Cart");
        }
    }

}