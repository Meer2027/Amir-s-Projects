package app.pizza_demofx.pizzademo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;

import java.io.*;

public class PizzaApplication extends Application {

    private static Stage primaryStage;

    @Override // start application and set screen to login
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(PizzaApplication.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1000, 600);
        stage.setTitle("Pizza Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    // change the scene to a given path
    public static void changeScene(String fxml){
        try {
            Parent newRoot = FXMLLoader.load(PizzaApplication.class.getResource(fxml));
            primaryStage.getScene().setRoot(newRoot);
        } catch (IOException e){
            System.out.println("There was a problem changing scenes " + e.getMessage());
        }
    }
}