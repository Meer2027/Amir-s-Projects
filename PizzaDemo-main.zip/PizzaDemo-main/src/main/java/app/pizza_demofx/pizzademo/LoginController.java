package app.pizza_demofx.pizzademo;

import java.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.io.*;

public class LoginController {

    private static ArrayList<User> valid_users;
    private static User current_user;
    private String currentUsername;
    private String currentPassword;
    private static File userFile;

    @FXML
    private TextField username_box;

    @FXML
    private PasswordField password_box;

    @FXML
    private Label fail_label;

    // scene constructor which initializes the current username and password variables and loads user information
    public LoginController(){
        valid_users = new ArrayList<User>();
        currentUsername = "";
        currentPassword = "";
        userFile = new File("user_data.txt");
        loadUsers();
    }

    //attempts to log in with current data entered
    @FXML
    protected void attemptLogin(){
        updateUserInfo();
        for (int i = 0; i < valid_users.size(); i++){
            if (valid_users.get(i).userMatch(currentUsername)){
                if(valid_users.get(i).passwordMatch(currentPassword)){
                    fail_label.setVisible(false);
                    current_user = valid_users.get(i);
                    loginAsUser();
                    return;
                }
                fail_label.setText("Incorrect Username or Password"); // fail to login due to incorrect password
                fail_label.setVisible(true);
                return;
            }
            fail_label.setText("Incorrect Username or Password"); // fail to login due to invalid username
            fail_label.setVisible(true);
        }
    }

    // change scene to menu once user logs in
    private void loginAsUser(){
        PizzaApplication.changeScene("menu.fxml");
    }

    // update username and password variables based on content in the boxes
    private void updateUserInfo(){
        currentUsername = username_box.getText();
        currentPassword = password_box.getText();
    }

    // converts "database" file data into user objects
    public static void loadUsers(){

        Scanner scan;
        try{
            scan = new Scanner(userFile);
            while(scan.hasNextLine()){
                String line = scan.nextLine();
                String[] line_split = line.split(",");
                if (line_split.length == 2){
                    // add new user with username and password as read and empty cart
                    valid_users.add(new User(line_split[0],line_split[1]));
                } else if (line_split.length == 3){
                    // add new user with username, password and cart
                    valid_users.add(new User(line_split[0],line_split[1],line_split[2]));
                }
            }
            scan.close();
        }catch(IOException e){
            System.out.println("There was a problem reading file " + userFile + "\nError message: " + e);
        }catch(IllegalArgumentException e){
            System.out.println("There was a problem reading file " + userFile + "\n Incorrect file format. Error message: " + e);
        }
    }

    // get the current cart which may be used in other scenes
    public static ArrayList<PizzaMenuItem> getCurrentCart(){
        return current_user.getCart();
    }

    // saves the current user's information (username, password, cart)
    public static void saveUser(){
        try{
            PrintWriter pw = new PrintWriter(userFile);
            for (int i = 0; i < valid_users.size(); i++){
                if (valid_users.get(i).userMatch(current_user.getUsername())){
                    pw.println(current_user.saveString()); // change the line for the current user information
                } else {
                    pw.println(valid_users.get(i).saveString()); // no change
                }
            }
            pw.close();
        }catch(IOException e){
            System.out.println("There was a problem writing to file " + userFile + "\nError message: " + e);
        }
    }
}
