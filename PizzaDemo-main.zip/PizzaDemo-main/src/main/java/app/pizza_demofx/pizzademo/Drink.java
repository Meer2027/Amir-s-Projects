package app.pizza_demofx.pizzademo;

public class Drink extends PizzaMenuItem{
    private String size;
    private String drink;

    // default constructor
    public Drink(){
        size = "Medium";
        drink = "Coca Cola";
    }

    // custom constructor
    public Drink(String size, String drink){
        this.size = size;
        this.drink = drink;
    }

    // calculates and returns the price of the item
    public double getPrice(){
        if (size.toUpperCase().equals("SMALL")){
            return 2.99;
        }
        if (size.toUpperCase().equals("MEDIUM")){
            return 3.59;
        }
        return 3.99;
    }

    // change the size to new specified size
    public void setSize(String size){
        this.size = size;
    }

    // change the drink to new specified drink type
    public void setDrink(String drink){
        this.drink = drink;
    }

    //used to display item as text
    @Override
    public String toString(){
        return size + " " + drink;
    }

    //used to save item in file
    public String saveString(){
        return "drinkitem__:" + size + "__:" + drink;
    }

    // get size of the drink
    public String getSize(){
        return size;
    }

    // get drink type
    public String getDrink(){
        return drink;
    }
}
