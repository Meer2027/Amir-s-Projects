package app.pizza_demofx.pizzademo;

import java.util.ArrayList;

public class Pizza extends PizzaMenuItem {

    private ArrayList<String> toppings;
    private String crustType;
    private String size;

    // Default constructor
    public Pizza() {
        this.toppings = new ArrayList<>();
        this.crustType = "";
        this.size = "Medium";
    }

    // Custom constructor without toppings
    public Pizza(String size, String crustType) {
        this.toppings = new ArrayList<>();
        this.crustType = crustType;
        this.size = size;
    }

    // Custom constructor
    public Pizza(ArrayList<String> toppings, String crustType, String size) {
        this.toppings = toppings;
        this.crustType = crustType;
        this.size = size;
    }

    // Add a topping
    public void addTopping(String topping) {
        toppings.add(topping);
    }

    // Remove a topping
    public void removeTopping(String topping) {
        toppings.remove(topping);
    }

    // Set crust
    public void setCrust(String crustType) {
        this.crustType = crustType;
    }

    // Set size
    public void setSize(String size) {
        this.size = size;
    }

    // Calculate price
    public double getPrice() {
        double price = 0.0;

        // Size pricing
        switch (size.toLowerCase()) {
            case "small":
                price += 9.99;
                break;
            case "medium":
                price += 12.99;
                break;
            case "large":
                price += 15.99;
                break;
            default:
                price += 19.99; // unknown size
        }

        // Toppings pricing
        price += toppings.size() * 0.89;

        // Crust pricing
        if (crustType.equalsIgnoreCase("stuffed")) {
            price += 2.59;
        }

        return Math.round(price * 100.0) / 100.0;
    }

    // used to save item in file
    public String saveString(){
        return "pizzaitem" + "__:" + size + "__:" + crustType+ "__:" + getPrintToppings();
    }

    // Returns a string which lists all pizza toppings for save file purposes
    public String getPrintToppings() {
        String toppingString = "";
        for (int i = 0; i < toppings.size(); i++) {
            if(i!=0) {
                toppingString += "@@:" + toppings.get(i);
            } else {
                toppingString += toppings.get(i);
            }
        }
        return toppingString;
    }

    // short version of toString method which omits specific toppings and displays only topping number
    public String toStringShort() {
        String toppingCount = toppings.size() + "-topping";

        // If crust type is empty, omit it
        if (crustType.isEmpty()) {
            return size + " " + toppingCount + " pizza";
        }

        return size + " " + toppingCount + " " + crustType + "-crust pizza";
    }

    // toString method
    @Override
    public String toString() {
        String toppingString = "";
        if(toppings.size() == 0){ // No toppings so format string differently
            // If crust type is empty, omit it
            if (crustType.isEmpty()) {
                return size + " cheese pizza";
            }
            return size + " " + crustType + " cheese pizza";
        } else if(toppings.size() == 1){ // Only one topping so topping string is just that topping
            toppingString = toppings.get(0);
        }
        else { // More than one topping so more complex string is needed
            for (int i = 0; i < toppings.size(); i++) {
                if (i == 0) {
                    toppingString += toppings.get(i);
                }
                if (i > 0) {
                    toppingString += ", " + toppings.get(i);
                } else if (i == toppings.size() - 1) {
                    toppingString += "and " + toppings.get(i);
                }
            }
        }

        // If crust type is empty, omit it
        if (crustType.isEmpty()) {
            return size + " pizza with " + toppingString;
        }

        return size + " " + crustType + "-crust pizza with " + toppingString;
    }

    // Getter for toppings list
    public ArrayList<String> getToppings() {
        return toppings;
    }

    // Getter for crust type
    public String getCrustType() {
        return crustType;
    }

    // Getter for
    public String getSize() {
        return size;
    }

}
