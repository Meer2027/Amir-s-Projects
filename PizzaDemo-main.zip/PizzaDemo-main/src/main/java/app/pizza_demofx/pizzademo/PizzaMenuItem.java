package app.pizza_demofx.pizzademo;

public abstract class PizzaMenuItem {
    // get price of the menu item
    public abstract double getPrice();
    // get the string intended for saving for the menu item
    public abstract String saveString();
}
