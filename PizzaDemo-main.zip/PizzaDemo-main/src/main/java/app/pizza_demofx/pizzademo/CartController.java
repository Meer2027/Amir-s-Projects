package app.pizza_demofx.pizzademo;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class CartController {

    // update cart information upon initial load of the screen
    public void initialize(){
        refresh();
    }

    private double computedTotal = 0.0;

    @FXML
    private Label totalLabel;

    @FXML
    private VBox dynamicVbox;

    @FXML // when sign out button is pressed, save user information and change to login scene
    protected void onSignOut(){
        LoginController.saveUser();
        PizzaApplication.changeScene("login.fxml");
    }

    @FXML // when menu button is pressed, change to menu scene
    protected void onMenuPress(){
        PizzaApplication.changeScene("menu.fxml");
    }

    // adds cart element of specified index onto cart screen
    protected void addCartElement(int index){
        if(LoginController.getCurrentCart().get(index) != null) {
            VBox parentVbox = new VBox();
            Label itemLabel = new Label(LoginController.getCurrentCart().get(index).toString() + ": $" + LoginController.getCurrentCart().get(index).getPrice());
            computedTotal += LoginController.getCurrentCart().get(index).getPrice();
            Button button = new Button("Remove"); // remove button
            button.setOnAction(actionEvent -> { // remove button action for the cart item
                LoginController.getCurrentCart().remove(index);
                refresh();
            });
            parentVbox.setStyle("-fx-border-width: 2; -fx-border-color: BLACK; -fx-border-insets: 5px;");
            parentVbox.getChildren().addAll(itemLabel, button);
            dynamicVbox.getChildren().add(parentVbox); // add cart element to the scene
        }
    }

    // called initially, and whenever a "remove" button is pressed to update cart information
    protected void refresh(){
        computedTotal = 0;
        dynamicVbox.getChildren().clear();
        for(int i = 0; i < LoginController.getCurrentCart().size(); i++){
            addCartElement(i);
        }
        totalLabel.setText("Total: $" + computedTotal);
    }

}
